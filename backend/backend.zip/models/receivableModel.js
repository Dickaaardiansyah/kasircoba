// models/receivableModel.js
// ─────────────────────────────────────────────────────────────────────────────
// MODEL LAYER — akses data untuk Piutang (tagihan ke pelanggan) & histori
// pembayarannya. Status ('belum_lunas' | 'sebagian' | 'lunas') selalu
// dihitung ulang di service dari amount vs paid_amount, model hanya
// menyimpan nilai final yang dikirim service.
// ─────────────────────────────────────────────────────────────────────────────
const {
  query,
  queryOne,
  insert,
  execute,
  transaction,
} = require("../config/database");

const receivableModel = {
  create({
    invoiceCode,
    customerId,
    customerName,
    transactionId,
    amount,
    paidAmount,
    invoiceDate,
    dueDate,
    status,
    notes,
    recordedBy,
  }) {
    return insert(
      `INSERT INTO receivables
         (invoice_code, customer_id, customer_name, transaction_id, amount, paid_amount,
          invoice_date, due_date, status, notes, recorded_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        invoiceCode,
        customerId || null,
        customerName,
        transactionId || null,
        amount,
        paidAmount || 0,
        invoiceDate,
        dueDate,
        status,
        notes || "",
        recordedBy || "Admin",
      ],
    );
  },

  findAll({ status, customerId, search, overdueOnly, limit, offset }) {
    let where = "WHERE 1=1";
    const params = [];
    if (status) {
      where += " AND r.status = ?";
      params.push(status);
    }
    if (customerId) {
      where += " AND r.customer_id = ?";
      params.push(customerId);
    }
    if (search) {
      where += " AND (r.invoice_code LIKE ? OR r.customer_name LIKE ?)";
      params.push(`%${search}%`, `%${search}%`);
    }
    if (overdueOnly) {
      where += " AND r.status != 'lunas' AND r.due_date < CURDATE()";
    }

    const listSql = `SELECT r.* FROM receivables r ${where} ORDER BY r.due_date ASC, r.created_at DESC`;
    if (!limit) return query(listSql, params);

    return Promise.all([
      query(
        `SELECT COUNT(*) AS total FROM receivables r ${where}`,
        params,
      ).then((r) => r[0]?.total || 0),
      query(`${listSql} LIMIT ? OFFSET ?`, [...params, limit, offset]),
    ]).then(([total, rows]) => ({ total, rows }));
  },

  findById(id) {
    return queryOne("SELECT * FROM receivables WHERE id = ?", [id]);
  },

  findByInvoiceCode(code) {
    return queryOne("SELECT * FROM receivables WHERE invoice_code = ?", [code]);
  },

  updatePaidAmount(id, paidAmount, status) {
    return execute(
      "UPDATE receivables SET paid_amount = ?, status = ? WHERE id = ?",
      [paidAmount, status, id],
    );
  },

  remove(id) {
    return execute("DELETE FROM receivables WHERE id = ?", [id]);
  },

  // ─── Pembayaran ──────────────────────────────────────────────────────────
  async addPayment(
    receivableId,
    { amount, paymentDate, paymentMethod, notes, recordedBy },
    newPaidAmount,
    newStatus,
  ) {
    return transaction(async (conn) => {
      const [payResult] = await conn.execute(
        `INSERT INTO receivable_payments (receivable_id, amount, payment_date, payment_method, notes, recorded_by)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [
          receivableId,
          amount,
          paymentDate,
          paymentMethod || "cash",
          notes || "",
          recordedBy || "Admin",
        ],
      );
      await conn.execute(
        "UPDATE receivables SET paid_amount = ?, status = ? WHERE id = ?",
        [newPaidAmount, newStatus, receivableId],
      );
      return payResult.insertId;
    });
  },

  findPayments(receivableId) {
    return query(
      "SELECT * FROM receivable_payments WHERE receivable_id = ? ORDER BY payment_date DESC, created_at DESC",
      [receivableId],
    );
  },

  // ─── Laporan: Faktur Belum Lunas per Pelanggan ─────────────────────────
  unpaidGroupedByCustomer() {
    return query(
      `SELECT COALESCE(r.customer_id, 0) AS customer_id, r.customer_name,
              COUNT(*) AS total_faktur,
              SUM(r.amount) AS total_tagihan,
              SUM(r.paid_amount) AS total_dibayar,
              SUM(r.amount - r.paid_amount) AS total_sisa,
              MIN(r.due_date) AS jatuh_tempo_terdekat
       FROM receivables r
       WHERE r.status != 'lunas'
       GROUP BY r.customer_id, r.customer_name
       ORDER BY total_sisa DESC`,
    );
  },

  // ─── Laporan: Umur Piutang (Aging) ──────────────────────────────────────
  agingReport() {
    return query(
      `SELECT r.id, r.invoice_code, r.customer_name, r.amount, r.paid_amount,
              (r.amount - r.paid_amount) AS sisa_tagihan, r.due_date,
              DATEDIFF(CURDATE(), r.due_date) AS hari_terlambat,
              CASE
                WHEN DATEDIFF(CURDATE(), r.due_date) <= 0 THEN 'belum_jatuh_tempo'
                WHEN DATEDIFF(CURDATE(), r.due_date) BETWEEN 1 AND 30 THEN '1-30'
                WHEN DATEDIFF(CURDATE(), r.due_date) BETWEEN 31 AND 60 THEN '31-60'
                WHEN DATEDIFF(CURDATE(), r.due_date) BETWEEN 61 AND 90 THEN '61-90'
                ELSE '90+'
              END AS bucket
       FROM receivables r
       WHERE r.status != 'lunas'
       ORDER BY hari_terlambat DESC`,
    );
  },

  // ─── Laporan: Histori Piutang (transaksi + pembayaran per pelanggan) ───
  history({ startDate, endDate, customerId }) {
    let where = "WHERE 1=1";
    const params = [];
    if (startDate) {
      where += " AND rp.payment_date >= ?";
      params.push(startDate);
    }
    if (endDate) {
      where += " AND rp.payment_date <= ?";
      params.push(endDate);
    }
    if (customerId) {
      where += " AND r.customer_id = ?";
      params.push(customerId);
    }
    return query(
      `SELECT rp.id, rp.payment_date, rp.amount, rp.payment_method, rp.notes,
              r.invoice_code, r.customer_name, r.amount AS total_tagihan
       FROM receivable_payments rp
       JOIN receivables r ON rp.receivable_id = r.id
       ${where}
       ORDER BY rp.payment_date DESC, rp.created_at DESC`,
      params,
    );
  },

  // ─── Ringkasan untuk monitoring/dashboard ───────────────────────────────
  summary() {
    return queryOne(
      `SELECT
         COUNT(*) AS total_faktur_belum_lunas,
         COALESCE(SUM(amount - paid_amount), 0) AS total_piutang,
         COALESCE(SUM(CASE WHEN due_date < CURDATE() THEN amount - paid_amount ELSE 0 END), 0) AS total_jatuh_tempo,
         COUNT(CASE WHEN due_date < CURDATE() THEN 1 END) AS jumlah_jatuh_tempo
       FROM receivables WHERE status != 'lunas'`,
    );
  },
};

module.exports = receivableModel;
