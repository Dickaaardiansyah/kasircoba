// models/capitalModel.js
// ─────────────────────────────────────────────────────────────────────────────
// MODEL LAYER — modul Modal Usaha: riwayat setoran modal (termasuk Modal Awal)
// dan penarikan modal (prive) oleh pemilik. Query mentah saja; aturan bisnis
// (validasi Modal Awal hanya boleh satu, posting jurnal otomatis) hidup di
// services/capitalService.js.
// ─────────────────────────────────────────────────────────────────────────────
const { query, queryOne, insert } = require("../config/database");

const capitalModel = {
  create({
    transactionCode,
    transactionDate,
    type,
    isInitial,
    targetAccount,
    amount,
    description,
    recordedBy,
  }) {
    return insert(
      `INSERT INTO capital_transactions
         (transaction_code, transaction_date, type, is_initial, target_account, amount, description, recorded_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        transactionCode,
        transactionDate,
        type,
        isInitial ? 1 : 0,
        targetAccount || "kas",
        amount,
        description || "",
        recordedBy || "",
      ],
    );
  },

  findById(id) {
    return queryOne("SELECT * FROM capital_transactions WHERE id = ?", [id]);
  },

  // Modal Awal usaha — hanya boleh ada satu baris dengan is_initial = 1.
  findInitial() {
    return queryOne(
      "SELECT * FROM capital_transactions WHERE is_initial = 1 LIMIT 1",
    );
  },

  findAll({ type, startDate, endDate, limit = 20, offset = 0 } = {}) {
    const params = [];
    let where = "WHERE 1=1";
    if (type) {
      where += " AND type = ?";
      params.push(type);
    }
    if (startDate) {
      where += " AND transaction_date >= ?";
      params.push(startDate);
    }
    if (endDate) {
      where += " AND transaction_date <= ?";
      params.push(endDate);
    }

    return Promise.all([
      queryOne(
        `SELECT COUNT(*) AS total FROM capital_transactions ${where}`,
        params,
      ),
      query(
        `SELECT * FROM capital_transactions ${where}
         ORDER BY is_initial DESC, transaction_date DESC, id DESC
         LIMIT ? OFFSET ?`,
        [...params, limit, offset],
      ),
    ]).then(([totalRow, rows]) => ({
      total: Number(totalRow?.total || 0),
      rows,
    }));
  },

  // Total setoran & penarikan sepanjang waktu — dasar ringkasan Modal Usaha.
  sumTotals() {
    return queryOne(
      `SELECT
         COALESCE(SUM(CASE WHEN type = 'setoran' THEN amount ELSE 0 END), 0) AS total_setoran,
         COALESCE(SUM(CASE WHEN type = 'setoran' AND is_initial = 0 THEN amount ELSE 0 END), 0) AS total_setoran_tambahan,
         COALESCE(SUM(CASE WHEN type = 'penarikan' THEN amount ELSE 0 END), 0) AS total_penarikan
       FROM capital_transactions`,
    );
  },
};

module.exports = capitalModel;
